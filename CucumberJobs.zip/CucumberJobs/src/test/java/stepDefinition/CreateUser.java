package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

public class CreateUser {
	WebDriver driver;
	WebDriverWait wait;
	Double d = (Math.random() + 1) * 1000;
	String username="newuser_"+Math.round(d);
	String emailId=username+"@gmail.com";
			
	@Given ("^User opens a browser$")
	public void openBrowser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\chromedriver.exe");
		driver=new ChromeDriver();
		wait=new WebDriverWait(driver,20);
		
	}
	
	
    @When ("^User navigates to Alchemy jobs and logs in$")
   public void login() throws Throwable{
    	driver.get("https://alchemy.hguy.co/jobs/wp-admin");
    	driver.manage().window().maximize();
    	driver.findElement(By.id("user_login")).clear();
    	driver.findElement(By.id("user_login")).sendKeys("root");
    	driver.findElement(By.id("user_pass")).clear();
    	driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");
    	driver.findElement(By.id("wp-submit")).submit();
    }
    @Then("^User clicks on the menu item that says Users on left hand menu$")
    public void clickOnUsers() {
    	driver.findElement(By.xpath("//*[@id='menu-users']/a/div[3]")).click();
    }
    
    @And("^User locates the add new button and clicks it$")
    public void clickAddNewButton() {
    	driver.findElement(By.linkText("Add New")).click();
    }
   @Then("^User fills all the necessary details$")
   public void fillUserDetails()
   {
	   driver.findElement(By.id("user_login")).clear();
	   driver.findElement(By.id("user_login")).sendKeys(username);
	   driver.findElement(By.id("email")).clear();
	   driver.findElement(By.id("email")).sendKeys(emailId);
	   
   }
   
    @And("^User clicks on Add New User button$")
    public void clickAddNewUserButton() {
    	driver.findElement(By.id("createusersub")).submit();
    	
    }
    @Then("^Verify the user was created$")
    public void verifyUserCreation() {
    	driver.findElement(By.id("user-search-input")).clear();
        driver.findElement(By.id("user-search-input")).sendKeys(username);
        driver.findElement(By.id("search-submit")).click();
        String actualUserName = driver.findElement(By.linkText(username)).getText();
        Assert.assertEquals(actualUserName,username );
    }
        @And("^Close the browser$")
        public void closeBrowser() throws Throwable{
        	driver.quit();
        }

}



